# Calculadora Básica

Este é um projeto simples de uma calculadora que realiza as quatro operações matemáticas básicas: adição, subtração, multiplicação e divisão.

## Como usar

Execute o script Python:

```bash
python main.py
```

Siga as instruções no terminal para realizar os cálculos.
